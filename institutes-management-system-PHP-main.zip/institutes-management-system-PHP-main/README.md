#INFORMATION
![Screenshot (4)](https://github.com/git-aditya-pratap-singh/crescdata/assets/68802755/90961012-c093-4f89-a483-46da51687007)

![Screenshot (2)](https://github.com/git-aditya-pratap-singh/crescdata/assets/68802755/5c2fe833-774b-4a22-aef6-1bb68eddb0d1)

![Screenshot (3)](https://github.com/git-aditya-pratap-singh/crescdata/assets/68802755/c3fce97b-f078-4145-afd2-b92ac31ce3c6)
